﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Helpers;
using System.Data.SqlClient;
using System.Data;

public partial class Default4 : System.Web.UI.Page
{
    helper db = new helper();
    string username;
    public string img = "images/loginFace.png";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["cart"] != null)
        {
            List<products> cart_list = Session["cart"] as List<products>;

            count_lbl.Text = cart_list.Count.ToString();
        }

        BindData();
    }
    bool reg()
    {
        db.values.Add("first", t1.Text);
        db.values.Add("last", t2.Text);
        db.values.Add("mobile", t3.Text);
        db.values.Add("gender", RadioButtonList1.Text);
        db.values.Add("address", t4.Text);
        db.values.Add("email", t5.Text);
        db.values.Add("password", t6.Text);
        db.values.Add("image", img);



        if (db.insert("registration", db.values))
        {
            return true;

        }
        else
        {
            return false;
        }
    }


    protected void signup_Click(object sender, EventArgs e)
    {

      





        if (reg())
        {
            msg_lbl.Text = "Registration Successful";
            t1.Text = "";
            t2.Text = "";
            t3.Text = "";
            t4.Text = "";
            t5.Text = "";
            RadioButtonList1.Text = "";

        }
        else
        {
            msg_lbl.Text = "Failed to Register";
        }

        /*SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=G:\military project\App_Data\Database.mdf;Integrated Security=True");
        String q = "insert into registration([first],[last],[mobile],[gender],[address],[email],[password]) values(@first,@last,@mobile,@gender,@address,@email,@password)";
        SqlCommand cmd = new SqlCommand(q, con);
        con.Open();
        cmd.Parameters.AddWithValue("@first", fname_tb.Text);
        cmd.Parameters.AddWithValue("@last", lname_tb.Text);
        cmd.Parameters.AddWithValue("@mobile", mobile_tb.Text);
        cmd.Parameters.AddWithValue("@gender", RadioButtonList1.Text);
        cmd.Parameters.AddWithValue("@address", Address_tb.Text);
        cmd.Parameters.AddWithValue("@email", email_tb.Text);
        cmd.Parameters.AddWithValue("@password", password_tb.Text);
        cmd.ExecuteNonQuery();
        con.Close();
        msg_lbl.Text = "inserted";
        */
    }



    void signin()
    {
        if (email_tb.Text == "admin" && password_tb.Text == "admin")
        {
            Response.Redirect("~/Admin Panel/AddProducts.aspx");
        }
        else
        {
            username = email_tb.Text.Trim();
            string q = "select COUNT(email) from registration where email='" + email_tb.Text + "' AND password='" + password_tb.Text + "'";

            int res = db.get_scalar(q);
            if (res > 0)
            {
                Session["username"] = username;
                Response.Redirect("~/userPanel/index.aspx");


            }
            else
            {
                Label1.Text = "Enter Correct Details";
                //message box

                string message = "Login failed ";

                System.Text.StringBuilder sb = new System.Text.StringBuilder();

                sb.Append("<script type = 'text/javascript'>");

                sb.Append("window.onload=function(){");

                sb.Append("alert('");

                sb.Append(message);

                sb.Append("')};");

                sb.Append("</script>");

                ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                ////message box
            }
        }
    }



    protected void login_Click1(object sender, EventArgs e)
    {
        signin();
    }


    private void BindData()
    {

        //SqlConnection myConnection = new SqlConnection("Data Source=.; uid=sa; pwd=wintellect;database=registration;");
        db.Connection.Open();

        SqlCommand myCommand = new SqlCommand("usp_GetProductsForCategories", db.Connection);

        myCommand.CommandType = CommandType.StoredProcedure;

        SqlDataAdapter ad = new SqlDataAdapter(myCommand);

        DataSet ds = new DataSet();

        ad.Fill(ds);

        // Attach the relationship to the dataSet

        ds.Relations.Add(new DataRelation("CategoriesRelation", ds.Tables[0].Columns["Id"],

        ds.Tables[1].Columns["Id"]));

        outerRep.DataSource = ds.Tables[0];

        outerRep.DataBind();

        db.Connection.Close();


    }

    protected void outerRep_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {



        if (e.Item.ItemType == ListItemType.Item ||

        e.Item.ItemType == ListItemType.AlternatingItem)
        {

            DataRowView drv = e.Item.DataItem as DataRowView;

            Repeater innerRep = e.Item.FindControl("innerRep") as Repeater;

            innerRep.DataSource = drv.CreateChildView("CategoriesRelation");

            innerRep.DataBind();

        }

    }

    protected void bb1_Click(object sender, EventArgs e)
    {
        signin();
    }
}