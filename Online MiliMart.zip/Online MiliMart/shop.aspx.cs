﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using Database_Helpers;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    helper db = new helper();

    string username;

    public List<products> product_list = new List<products>();


    public string idd;

    protected void Page_Load(object sender, EventArgs e)
    {
        idd = Request.Params["qq"];
        load_menu();

        BindData();
    }





    void load_menu()
    {
      
                db.Connection.Open();
                string q = "select * from products where catagory='"+idd+"'";
                SqlCommand cmd = new SqlCommand(q, db.Connection);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        product_list.Add(new products(reader["Id"].ToString(), reader["catagory"].ToString(), reader["name"].ToString(), reader["price"].ToString(), reader["image"].ToString(),reader["avlqty"].ToString()));
                    }
                }
                db.Connection.Close();

    }


    void signin()
    {
        if (email_tb.Text == "admin" && password_tb.Text == "admin")
        {
            Response.Redirect("~/Admin Panel/AddProducts.aspx");
        }
        else
        {
            username = email_tb.Text.Trim();
            string q = "select COUNT(email) from registration where email='" + email_tb.Text + "' AND password='" + password_tb.Text + "'";

            int res = db.get_scalar(q);
            if (res > 0)
            {
                Session["username"] = username;
                Response.Redirect("~/userPanel/index.aspx");


            }
            else
            {
                Label1.Text = "Enter Correct Details";
                //message box

                string message = "Login failed ";

                System.Text.StringBuilder sb = new System.Text.StringBuilder();

                sb.Append("<script type = 'text/javascript'>");

                sb.Append("window.onload=function(){");

                sb.Append("alert('");

                sb.Append(message);

                sb.Append("')};");

                sb.Append("</script>");

                ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                ////message box
            }
        }
    }



    protected void login_Click1(object sender, EventArgs e)
    {
        signin();
    }

    private void BindData()
    {

        //SqlConnection myConnection = new SqlConnection("Data Source=.; uid=sa; pwd=wintellect;database=registration;");
        db.Connection.Open();

        SqlCommand myCommand = new SqlCommand("usp_GetProductsForCategories", db.Connection);

        myCommand.CommandType = CommandType.StoredProcedure;

        SqlDataAdapter ad = new SqlDataAdapter(myCommand);

        DataSet ds = new DataSet();

        ad.Fill(ds);

        // Attach the relationship to the dataSet

        ds.Relations.Add(new DataRelation("CategoriesRelation", ds.Tables[0].Columns["Id"],

        ds.Tables[1].Columns["Id"]));

        outerRep.DataSource = ds.Tables[0];

        outerRep.DataBind();

        db.Connection.Close();


    }

    protected void outerRep_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {



        if (e.Item.ItemType == ListItemType.Item ||

        e.Item.ItemType == ListItemType.AlternatingItem)
        {

            DataRowView drv = e.Item.DataItem as DataRowView;

            Repeater innerRep = e.Item.FindControl("innerRep") as Repeater;

            innerRep.DataSource = drv.CreateChildView("CategoriesRelation");

            innerRep.DataBind();

        }

    }

}