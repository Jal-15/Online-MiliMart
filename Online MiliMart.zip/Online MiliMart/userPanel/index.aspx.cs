﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Helpers;
using System.Data.SqlClient;
using System.Data;

public partial class userPanel_index : System.Web.UI.Page
{
    helper db = new helper();
    public List<products> product_list = new List<products>();

    public string qq;
    public string fname;
    public string lname;
    public string imagepath;

    SqlDataAdapter sda = new SqlDataAdapter();
    DataSet ds = new DataSet();


    string t1;
    string t2;
    string t3;
    string t4;
    string t5;
    string t6;



    string name;

    protected void Page_Load(object sender, EventArgs e)
    {


        loadprod();       
    }

    void loadprod()
    {

        db.Connection.Open();
        string q = "select * from products";
        SqlCommand cmd = new SqlCommand(q, db.Connection);
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            while (reader.Read())
            {

                t1 = reader["Id"].ToString();
                t2 = reader["catagory"].ToString();
                t3 = reader["name"].ToString();
                t4 = reader["price"].ToString();
                t5 = reader["image"].ToString();
                t6 = reader["avlqty"].ToString();


                product_list.Add(new products(t1, t2, t3, t4, "../" + t5,t6));
                
            }


            
        }
        
        db.Connection.Close();
    }

    


   

}