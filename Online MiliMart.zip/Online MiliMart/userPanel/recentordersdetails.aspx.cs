﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class userPanel_Default2 : System.Web.UI.Page
{
    public static string connection = ConfigurationManager.ConnectionStrings["DefaultConnectionString"].ConnectionString;

    SqlConnection con = new SqlConnection(connection);
    protected void Page_Load(object sender, EventArgs e)
    {
        load_order();
    }
    void load_order()
    {
        string sessionid = Request.QueryString["order_id"].ToString();
        string q = "select MAX(cartTotal) from carts where session_id='" + sessionid + "'";
        SqlCommand cmd = new SqlCommand(q, con);
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();


        if (dr.Read())
        {
            lb.Text = "Cart Total :" + " " + dr[0].ToString();

        }
        else
        {
            Response.Write("no data found");
        }
        con.Close();
    }
}