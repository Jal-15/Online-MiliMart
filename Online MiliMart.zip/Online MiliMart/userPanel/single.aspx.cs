﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using Database_Helpers;

public partial class userPanel_Default4 : System.Web.UI.Page
{
    helper db = new helper();

    public string prod_id;

    string t1;
    string t2;
    string t3;
    string t4;
    string t5;
    string t6;


    public List<products> product_list = new List<products>();

    static List<products> cart_list = new List<products>();

    protected void Page_Load(object sender, EventArgs e)
    {
        prod_id = Request.Params["pro_id"];
        load_prod();

        if (Request.QueryString.AllKeys.Contains("pro_id") && Request.QueryString.AllKeys.Contains("action"))
        {
            string pro_id = Request.QueryString["pro_id"];
            string action = Request.QueryString["action"];
            if (action.Equals("add"))
            {
                add_to_cart(pro_id);
            }
        }


        
    }


    void add_to_cart(string product_id)
    {
        var product = product_list.Where(x => x.Id == product_id);


        foreach (var data in product)
        {
            cart_list.Add(data);
        }

        Session["cart"] = cart_list;


    }

    void load_prod()
    {
        db.Connection.Open();
        string q = "select * from products where Id='" + prod_id + "'";
        SqlCommand cmd = new SqlCommand(q, db.Connection);
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                t1 = reader["Id"].ToString();
                t2 = reader["catagory"].ToString();
                t3 = reader["name"].ToString();
                t4 = reader["price"].ToString();
                t5 = reader["image"].ToString();
                t6 = reader["avlqty"].ToString();



                product_list.Add(new products(t1, t2, t3, t4, "../"+t5,t6));
            }
        }
        db.Connection.Close();
        
    }
}