﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Helpers;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class userPanel_userhome : System.Web.UI.MasterPage
{
   

    public string qq;
    public string fname;
    public string lname;
    public string imagepath;
    public static string connection = ConfigurationManager.ConnectionStrings["DefaultConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(connection);
    SqlDataAdapter sda = new SqlDataAdapter();
    DataSet ds = new DataSet();
    helper db = new helper();
    


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["cart"] != null)
        {
            List<products> cart_list = Session["cart"] as List<products>;

            count_lbl.Text = cart_list.Count.ToString();
        }



        if (Session["username"] == null)
        {
            Response.Redirect("index.aspx");
        }

        else 
        {
            showdata();
        }

        BindData();


        
    }


    void showdata()
    {
        
        string q = "select * from registration where email='" + Session["username"] + "'";
        SqlCommand cmd = new SqlCommand(q, con);
        con.Open();
        sda.SelectCommand = cmd;
        sda.Fill(ds);
        if (ds.Tables[0].Rows.Count == 1)
        {

            fname = ds.Tables[0].Rows[0]["first"].ToString();
            lname = ds.Tables[0].Rows[0]["last"].ToString();
            qq = ds.Tables[0].Rows[0]["email"].ToString();
            imagepath = ds.Tables[0].Rows[0]["image"].ToString();

            ulabel.Text ="Welcome "+ fname + " " + lname;
            con.Close();
        }


    }

    private void BindData()
    {

        //SqlConnection myConnection = new SqlConnection("Data Source=.; uid=sa; pwd=wintellect;database=registration;");
        db.Connection.Open();

        SqlCommand myCommand = new SqlCommand("usp_GetProductsForCategories", db.Connection);

        myCommand.CommandType = CommandType.StoredProcedure;

        SqlDataAdapter ad = new SqlDataAdapter(myCommand);

        DataSet ds = new DataSet();

        ad.Fill(ds);

        // Attach the relationship to the dataSet

        ds.Relations.Add(new DataRelation("CategoriesRelation", ds.Tables[0].Columns["Id"],

        ds.Tables[1].Columns["Id"]));

        outerRep.DataSource = ds.Tables[0];

        outerRep.DataBind();

        db.Connection.Close();


    }

    protected void outerRep_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {



        if (e.Item.ItemType == ListItemType.Item ||

        e.Item.ItemType == ListItemType.AlternatingItem)
        {

            DataRowView drv = e.Item.DataItem as DataRowView;

            Repeater innerRep = e.Item.FindControl("innerRep") as Repeater;

            innerRep.DataSource = drv.CreateChildView("CategoriesRelation");

            innerRep.DataBind();


        }

    }
}
