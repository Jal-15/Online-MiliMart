﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class userPanel_recentorders : System.Web.UI.Page
{
    //public static string connection = ConfigurationManager.ConnectionStrings["DefaultConnectionString"].ConnectionString;
   // SqlConnection con = new SqlConnection(connection);
    //SqlCommand cmd;
    //SqlDataReader dr, dr1;


    protected void Page_Load(object sender, EventArgs e)
    {
       
        displayorder();




    }
    void displayorder()
    {
        

    }
}