﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Helpers;
using System.Data.SqlClient;
using System.Data;


public partial class Admin_Panel_AddProducts : System.Web.UI.Page
{
    helper db = new helper();

    SqlDataReader dr,ddr;

    

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            loadcat();
        }
    }

    void loadcat()
    {
        db.Connection.Open();
        string qq = "select * from category";
        SqlCommand cmd = new SqlCommand(qq, db.Connection);

        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            ListItem newList = new ListItem();
            newList.Text = dr["name"].ToString();
            newList.Value = dr["Id"].ToString();
            this.drpcate.Items.Add(newList);
            
        }
        drpcate.Items.Insert(0, new ListItem ("--select--"));
        dr.Close();
        db.Connection.Close();
    }

    bool add_product()
    {
        db.values.Add("name", name_box.Text);
        db.values.Add("price", price_box.Text);
        db.values.Add("catagory", drpcate2.SelectedItem.Text);
        db.values.Add("avlqty", qty_box.Text);
        db.values.Add("image", "images/"+fileupload.FileName.ToString());
        if (db.insert("products", db.values))
        {
            return true;

        }
        else
        {
            return false;
        }
    }

    protected void add_btn_Click(object sender, EventArgs e)
    {
        if (add_product())
        {
            msglbl.Text = "Product Added Successfully";
            name_box.Text = "";
            price_box.Text = "";
        }
        else
        {
            msglbl.Text = "Failed to add Product";
        }
    }


    protected void drpcate_SelectedIndexChanged1(object sender, EventArgs e)
    {
        try
        {
            drpcate2.Items.Clear();

            db.Connection.Open();
            string idd, name;
            idd = drpcate.SelectedValue.ToString();
            name = drpcate.SelectedItem.Text;

            string qry = "select s_id,subcat_name from subcategory where Id='" + idd + "'";
            SqlCommand cm = new SqlCommand(qry, db.Connection);

            ddr = cm.ExecuteReader();
            while (ddr.Read())
            {
                ListItem nl = new ListItem();
                nl.Text = ddr["subcat_name"].ToString();
                nl.Value = ddr["s_id"].ToString();
                this.drpcate2.Items.Add(nl);
            }
            ddr.Close();

            db.Connection.Close();
        }

        catch (Exception ex)
        {

        }
            

    

        
        
    }

}