﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;


public partial class Admin_Panel_UserAccount : System.Web.UI.Page
{
    public static string connection = ConfigurationManager.ConnectionStrings["DefaultConnectionString"].ConnectionString;

    SqlConnection con = new SqlConnection(connection);

    public string imagepath;


    SqlCommand cmd;
    SqlDataReader dr, dr1; 
    
    protected void Page_Load(object sender, EventArgs e)
    {
        displayall();
    }

    void displayall()
    {
        con.Open();
        string q = "select * from registration";
        cmd = new SqlCommand(q, con);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            gv1.DataSource = dr;
            gv1.DataBind();
        }
        //cmd.ExecuteNonQuery();
        con.Close();

        int count = gv1.Rows.Count;
        lbl.Text = count.ToString();
    }



    protected void b1_Click(object sender, EventArgs e)
    {
        string name=t1.Text;
        con.Open();
        string q1 = "select * from registration where first LIKE '%" + name + "%' OR email LIKE '%"+name+"%' ";
        cmd = new SqlCommand(q1,con);
        dr1 = cmd.ExecuteReader();
        if (dr1.HasRows)
        {
            gv1.DataSource = dr1;
            gv1.DataBind();
        }
       
        con.Close();
    }


    protected void Display_All_Click(object sender, EventArgs e)
    {
        displayall();
        t1.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {


    }
}