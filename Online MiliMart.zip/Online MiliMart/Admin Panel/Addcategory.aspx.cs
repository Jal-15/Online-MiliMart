﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using Database_Helpers;
using System.Data;

public partial class Admin_Panel_addcategory : System.Web.UI.Page
{
    helper db=new helper();
    //public static string connection = ConfigurationManager.ConnectionStrings["DefaultConnectionString"].ConnectionString;
    //SqlConnection con = new SqlConnection(connection);

    protected void Page_Load(object sender, EventArgs e)
    {
        
        lbl1.Text = "";
    }
    protected void add_Click(object sender, EventArgs e)
    {
        string t = t1.Text;
        
        string q = "select * from category where name='" + t + "'";
        SqlCommand cd = new SqlCommand(q, db.Connection);
        SqlDataAdapter da = new SqlDataAdapter(cd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        int i = ds.Tables[0].Rows.Count;
        
        if (i>0)
        {
            lbl1.Text = "Category " + t + " already Exist";

            ds.Clear();
            
        }

        else
        {

          insertdata();
        }

        


       
    }

    void insertdata()
    {
        db.Connection.Open();
        
        string qry = "insert into category values('" + t1.Text + "')";
        SqlCommand cmd = new SqlCommand(qry, db.Connection);
        cmd.ExecuteNonQuery();
        lbl1.Text = "Category Added Successfully";

        db.Connection.Close();
        t1.Text = "";
    }
}