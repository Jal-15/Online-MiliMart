﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Helpers;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_Panel_orders : System.Web.UI.Page
{
    helper db = new helper();
    public static string connection = ConfigurationManager.ConnectionStrings["DefaultConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(connection);
    SqlDataReader dr,dr1;

    protected void Page_Load(object sender, EventArgs e)
    {
        gd1.DataSource = srchbyname;
        gd1.DataBind();
        srchname.Text = "";
    }


    protected void srch_Click(object sender, EventArgs e)
    {
        //order_ds.SelectCommand = "select * from orders where c_email='" + srch.Text + "'";
        //gd1.DataSource = order_ds.SelectCommand;
        //gd1.DataBind();
        //string q = "select * from orders where c_email='" + srch.Text + "'";
        //con.Open();
        //SqlCommand cmd = new SqlCommand(q, con);
        //cmd.ExecuteNonQuery();
        //dr = cmd.ExecuteReader();
        //while (dr.Read())
        //{
        //    gd1.DataSource = dr;
        //    gd1.DataBind();
        //}
        //con.Close();
        string qq = "select * from orders where c_name='"+srchname.Text+"'";
        con.Open();
        SqlCommand cmd = new SqlCommand(qq, con);
        cmd.ExecuteNonQuery();
        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            gd1.DataSource = dr;
            gd1.DataBind();
        }
        
    }
    protected void display_all_Click(object sender, EventArgs e)
    {
        gd1.DataSource = all;
        gd1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {


    }
}