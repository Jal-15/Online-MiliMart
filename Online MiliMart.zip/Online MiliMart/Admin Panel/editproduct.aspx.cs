﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Helpers;
using System.Data.SqlClient;
using System.Data;

public partial class Admin_Panel_editproduct : System.Web.UI.Page
{
    helper db = new helper();

    SqlDataReader dr, ddr;
    string qs;

    protected void Page_Load(object sender, EventArgs e)
    {
        qs = Request.QueryString["order_id"];
        if (!IsPostBack)
        {
            loadcat();
            showdata();
        }
        
    }



    void showdata()
    {
        db.Connection.Open();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter sda = new SqlDataAdapter();
        DataSet ds = new DataSet();
        DataTable dtbl = new DataTable();
        cmd.CommandText = "select * from products where Id='" + qs + "'";
        cmd.Connection = db.Connection;
        sda.SelectCommand = cmd;
        sda.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            name_box.Text = ds.Tables[0].Rows[0]["name"].ToString();
            price_box.Text = ds.Tables[0].Rows[0]["price"].ToString();
            qty_box.Text = ds.Tables[0].Rows[0]["avlqty"].ToString();
            db.Connection.Close();
        }
    }

    protected void updatebtn_Click(object sender, EventArgs e)
    {
        db.Connection.Open();
        string q = "update products set name=@name,catagory=@catagory,price=@price,image=@image,avlqty=@avlqty WHERE Id = '"+qs+"'";

        SqlCommand sqlCmd = new SqlCommand(q, db.Connection);
        sqlCmd.Parameters.AddWithValue("@name", name_box.Text);
        sqlCmd.Parameters.AddWithValue("@catagory", drpcate2.SelectedItem.Text);
        sqlCmd.Parameters.AddWithValue("@price", price_box.Text);
        sqlCmd.Parameters.AddWithValue("@image", "images/" + fileupload.FileName.ToString());
        sqlCmd.Parameters.AddWithValue("@avlqty", qty_box.Text);
        sqlCmd.ExecuteNonQuery();
        msglbl.Text = "Product Updated Successfully";
        db.Connection.Close();
    }
   


    void loadcat()
    {
        db.Connection.Open();
        string qq = "select * from category";
        SqlCommand cmd = new SqlCommand(qq, db.Connection);

        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            ListItem newList = new ListItem();
            newList.Text = dr["name"].ToString();
            newList.Value = dr["Id"].ToString();
            this.drpcate.Items.Add(newList);

        }
        drpcate.Items.Insert(0, new ListItem("--select--"));
        dr.Close();
        db.Connection.Close();
    }


    protected void drpcate_SelectedIndexChanged1(object sender, EventArgs e)
    {
        try
        {
            drpcate2.Items.Clear();

            db.Connection.Open();
            string idd, name;
            idd = drpcate.SelectedValue.ToString();
            name = drpcate.SelectedItem.Text;

            string qry = "select s_id,subcat_name from subcategory where Id='" + idd + "'";
            SqlCommand cm = new SqlCommand(qry, db.Connection);

            ddr = cm.ExecuteReader();
            while (ddr.Read())
            {
                ListItem nl = new ListItem();
                nl.Text = ddr["subcat_name"].ToString();
                nl.Value = ddr["s_id"].ToString();
                this.drpcate2.Items.Add(nl);
            }
            ddr.Close();

            db.Connection.Close();
        }

        catch (Exception ex)
        {

        }
    }
    protected void cancelbtn_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewProducts.aspx");
    }
}