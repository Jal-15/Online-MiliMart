﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Database_Helpers;

public partial class Admin_Panel_ViewProduct : System.Web.UI.Page
{
    string sort;
    DataTable dtbl = new DataTable();

    public static string connection = ConfigurationManager.ConnectionStrings["DefaultConnectionString"].ConnectionString;

    SqlConnection con = new SqlConnection(connection);
    SqlDataReader dr;
    SqlDataReader dr1;
    helper db = new helper();
    DropDownList dropdown = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            PopulateGridview();
           // search();
            gridview1.DataSource = dtbl;
            gridview1.DataBind();
            lblErrorMessage.Text = "";
            lblSuccessMessage.Text = "";
            
            
        }
        this.MaintainScrollPositionOnPostBack = true;

    }
    void PopulateGridview()
    {
        
        using (con)
        {
            con.Open();
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM products", con);
            sqlDa.Fill(dtbl);
            
        }

        if (dtbl.Rows.Count > 0)
        {
            gridview1.DataSource = dtbl;
            gridview1.DataBind();
        }
        else
        {
            dtbl.Rows.Add(dtbl.NewRow());
            gridview1.DataSource = dtbl;
            gridview1.DataBind();
            gridview1.Rows[0].Cells.Clear();
            gridview1.Rows[0].Cells.Add(new TableCell());
            gridview1.Rows[0].Cells[0].ColumnSpan = dtbl.Columns.Count;
            gridview1.Rows[0].Cells[0].Text = "No Data Found ..!";
            gridview1.Rows[0].Cells[0].HorizontalAlign = HorizontalAlign.Center;
        }
        
    }

    void search()
    {
        using (con)
        {
            string name = searchprd.Text;
            con.Open();
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM products WHERE name LIKE '%"+name+"%'", con);
            sqlDa.Fill(dtbl);
            

        }

        if (dtbl.Rows.Count > 0)
        {
            gridview1.DataSource = dtbl;
            gridview1.DataBind();
        }
        else
        {
            searchprd.Text = "";
            gridview1.Visible = false;
            lblErrorMessage.Text = "No Such Item Found";
            //gridview1.EmptyDataText = "No Such Menu Avaliable";
        }

    }
    

    protected void gridview1_RowEditing1(object sender, GridViewEditEventArgs e)
    {
        gridview1.EditIndex = e.NewEditIndex;
        search();
        //PopulateGridview();
    }

    protected void gridview1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gridview1.EditIndex = -1;
        search();
        //PopulateGridview();
    }

  


    protected void gridview1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        
    }

    protected void gridview1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        
    }

    
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        //string q = "select * from products where catagory="+sort+"";
        //SqlCommand cmd = new SqlCommand(q,con);
        //con.Open();
        
        //cmd.ExecuteNonQuery();
        //con.Close();
    }
   
    

    protected void searchbtn_Click(object sender, EventArgs e)
    {
        search();
    }

    protected void display_all_Click(object sender, EventArgs e)
    {
        searchprd.Text = "";
        lblErrorMessage.Text = "";
        gridview1.Visible = true;
        gridview1.DataSource = search_all;
        gridview1.DataBind();

    }



    protected void gridview1_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        foreach (GridViewRow gv in gridview1.Rows)
        {
            DropDownList ddl = (DropDownList)e.Row.FindControl("txtcatagory");
            
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {


    }
    
}