﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Database_Helpers;

public partial class Admin_Panel_Addsubcategory : System.Web.UI.Page
{
    helper db = new helper();

    SqlDataReader reader;

    protected void Page_Load(object sender, EventArgs e)
    {
        
            
            if (!IsPostBack)
            {

                //You can write here the code, which you want to execute in the first time when the page is loaded.

                display();

            }
       
        
    }
    protected void add_Click(object sender, EventArgs e)
    {
        updatecat();
        t1.Text = "";
       
    }

    void display()
    {

        db.Connection.Open();
        string qry = "select * from category";
        SqlCommand cmd = new SqlCommand(qry, db.Connection);

        reader = cmd.ExecuteReader();
        while(reader.Read())
        {
            ListItem l1 = new ListItem();
            l1.Text = reader["name"].ToString();
            l1.Value = reader["Id"].ToString();
            this.drp.Items.Add(l1);
        }
        reader.Close();
        db.Connection.Close();
    }


    void updatecat()
    {

        string checkq = "select * from subcategory where subcat_name='"+t1.Text+"'";
        SqlCommand cc = new SqlCommand(checkq,db.Connection);
        SqlDataAdapter da = new SqlDataAdapter(cc);
        DataSet sd = new DataSet();
        da.Fill(sd);

        int i = sd.Tables[0].Rows.Count;
        if (i>0)
        {
            lbl1.Text = "subcategory " + t1.Text + " already exits";
         
        }
        else
        {

            inrt();
        
           
        }

    }


    void inrt() 
    {
        db.Connection.Open();
        string qq = "insert into subcategory values('" + drp.SelectedValue + "','" + t1.Text + "')";
        SqlCommand cmd = new SqlCommand(qq, db.Connection);
        cmd.ExecuteNonQuery();
        lbl1.Text = "record inserted successfully";
        db.Connection.Close();
    }
}