﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Helpers;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class index : System.Web.UI.Page
{

    

    helper db = new helper();

    string username;

    public List<products> product_list = new List<products>();

    protected void Page_Load(object sender, EventArgs e)
    {
        BindData();
        
    }






    void signin()
    {
        if (email_tb.Text == "admin" && password_tb.Text == "admin")
        {
            Response.Redirect("~/Admin Panel/AddProducts.aspx");
        }
        else
        {
            username = email_tb.Text.Trim();
            string q = "select COUNT(email) from registration where email='" + email_tb.Text + "' AND password='" + password_tb.Text + "'";

            int res = db.get_scalar(q);
            if (res > 0)
            {
                Session["username"] = username;
                Response.Redirect("~/userPanel/index.aspx");


            }
            else
            {
                Label1.Text = "Enter Correct Details";
                //message box

                string message = "Login failed ";

                System.Text.StringBuilder sb = new System.Text.StringBuilder();

                sb.Append("<script type = 'text/javascript'>");

                sb.Append("window.onload=function(){");

                sb.Append("alert('");

                sb.Append(message);

                sb.Append("')};");

                sb.Append("</script>");

                ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                ////message box
            }
        }
    }

    protected void login_Click1(object sender, EventArgs e)
    {
        signin();
    }


    private void BindData()
    {

        
        db.Connection.Open();

        SqlCommand myCommand = new SqlCommand("usp_GetProductsForCategories", db.Connection);

        myCommand.CommandType = CommandType.StoredProcedure;

        SqlDataAdapter ad = new SqlDataAdapter(myCommand);

        DataSet ds = new DataSet();

        ad.Fill(ds);

        // Attach the relationship to the dataSet

        ds.Relations.Add(new DataRelation("CategoriesRelation", ds.Tables[0].Columns["Id"],

        ds.Tables[1].Columns["Id"]));

        outerRep.DataSource = ds.Tables[0];

        outerRep.DataBind();

        db.Connection.Close();


    }

    protected void outerRep_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {



        if (e.Item.ItemType == ListItemType.Item ||

        e.Item.ItemType == ListItemType.AlternatingItem)
        {

            DataRowView drv = e.Item.DataItem as DataRowView;

            Repeater innerRep = e.Item.FindControl("innerRep") as Repeater;

            innerRep.DataSource = drv.CreateChildView("CategoriesRelation");

            innerRep.DataBind();
            

        }

    }

}